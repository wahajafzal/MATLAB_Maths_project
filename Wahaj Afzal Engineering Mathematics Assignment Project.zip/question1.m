clc
%Question 1
%part a
syms x
x = dsolve('D2x+2*Dx+26*x = 10*cos(t)*heaviside(t-pi)','x(0)=0.5','Dx(0)=1');
fprintf('a) dsolve:')
fprintf('\n')
pretty(x)

%part b
fprintf('b) laplace and inverse laplace:')
fprintf('\n')
syms x(t) t s X
F= diff(x(t),t,2)+2*diff(x(t),t)+26*x(t)==10*cos(t)*heaviside(t-pi);
L = laplace(F, t, s);
lt =  subs(L, laplace(x, t, s), X);
lt = subs(lt, x(0), 0.5);
lt = subs(lt, subs(diff(x(t), t), t, 0), 1);
q = solve(lt,X);

%q = laplace(F,s);
pretty(q)

fprintf('\n')
i = @(t) ilaplace(q, s, t);
%inverse laplace
pretty(i(t))
fprintf('\n')

%partc
fprintf('c) plot:')
%solution at initial condition of x(t)=0
r = i(0);
fprintf('\n')
fprintf('solution at initial condition of x(t)=0')
r
fprintf('\n')
%solution at initial condition of x?(t)=0
w = diff(i,t,1);
fprintf('solution at initial condition of x?(t)=0')
subs(w,0)


y(t)= dsolve('D2x+2*Dx+26*x-10*cos(t)*heaviside(t-pi)','x(0)=0.5','Dx(0)=1');
y(t)=simplify(y);
s = 0:0.5:15;
sp = y(s);
figure
plot(s, sp, 0, 0.5, 'x')
grid("on")
title('dsolve at od')
xlabel('t')
ylabel('x(t)')

figure
s = [0, 15];
fplot(q,s)
grid("on")
title('laplace of od')
xlabel('t')
ylabel('x(t)')

figure
sa = [0, 15];
fplot(i(t),sa)
grid("on")
title('inverse laplace of od')
xlabel('t')
ylabel('x(t)')

