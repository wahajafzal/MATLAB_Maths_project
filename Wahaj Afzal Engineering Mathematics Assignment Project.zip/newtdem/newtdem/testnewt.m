format long % gives more decimals
x=[1;2]; % initial guess
y=multinewton(@myfunction,x,7); % calling your newtonsolver (multinewton) with your system (myfunction) with starting values x and do 7 iterations
y' % just print out the results on a line instead of column

