clc
format long % gives more decimals
x=[1; 0]; % initial guess
fprintf("<strong> a)</strong>")
fprintf('\n')
y=multinewton(@myfunction,x,20); 
fprintf("with given starting points[1,0]:")
fprintf('\n')
y
%with different inital guess
x2=[1;2];
v=multinewton(@myfunction,x2,20);
fprintf('\n')
fprintf("with different starting points[1,2]:")
fprintf('\n')
v

fprintf('\n')
fprintf("<strong> b)</strong>")
xm = fsolve(@myfunction,x);
fprintf('\n')
fprintf("with MATLAB built_in function on given starting points[1,0]:")
fprintf('\n')
xm

xv = fsolve(@myfunction,x2);
fprintf('\n')
fprintf("with MATLAB built_in function on different starting points[1,2]:")
fprintf('\n')
xv