clc
syms a b c X t f(w);
xn = [1; 2; 3; 4; 5; 6];
fxn = [2; 3; 1; 5; 4; 1];
table(xn, fxn)
something = [a; b; c];
h = 1;
x = 4;
fprintf("<strong> a)</strong> ")
fprintf('\n')
%forward differencing method: (f(x+h)-f(x))/h
fx5 = 4;
fx4 = 5;
fx3 = 1;
fprintf("forward differencing method: (f(x+h)-f(x))/h")
fd = (fx5 - fx4)/h;
fprintf('\n')
fprintf("f'(4)using forward differencing: ")
fd
%backward differencing method: (f(x)-f(x-h))/h
fprintf("backward differencing method: (f(x)-f(x-h))/h")
bd = (fx4 - fx3)/h;
fprintf('\n')
fprintf("f'(4)using backwar differencing method: ")
bd
%centerd differencing method: (f(x+h)-f(x-h))/h
fprintf("centerd differencing method: (f(x+h)-f(x-h))/h")
cd = (fx5 - fx3)/2*h;
fprintf('\n')
fprintf("f'(4) using centerd differencing methd: ")
cd

fprintf("<strong> b)</strong> ")
fprintf('\n')

ds = [1 xn(3) xn(3)*xn(3); 1 xn(4) xn(4)*xn(4); 1 xn(5) xn(5)*xn(5)];
d = [fxn(3); fxn(4); fxn(5)];
[X0, X1, X2] = solve(ds*something == d, something);
f(w) = X2*w^2 + X1*w + X0;
%second order interpolation polynomial = sip
sip = diff(f, w);
c = sip(4); %f'(4)
fprintf("f'(4) using 2nd oreder interpolation polynomial differencing: ")
eval(char(c))

fprintf("<strong>c)</strong>")
fprintf('\n')
trxs = 0;
%lower given limit is 1 upper given limit is 6
%trapezoidal rule = h*(0.5*f(n1)+f(n2)+f(n3)....+0.5f(n))
for i =1:6
    if (i == 1)||(i == 6)
        trxs = trxs +0.5*fxn(i);
    else
        trxs = trxs +fxn(i);
    end
end
trxs = trxs*h;

matlab = trapz(fxn(find(xn==1):find(xn==6)));
fprintf("trapezoidal rule using for loop scheme:")
trxs
fprintf('\n')
fprintf("trapezoidal rule using MATLAB function:")
matlab
