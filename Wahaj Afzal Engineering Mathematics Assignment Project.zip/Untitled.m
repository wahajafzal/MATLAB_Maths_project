clc
%Question 1
%part a
syms x
x = dsolve('D2x+2*Dx+26*x = 10*cos(t)*H(t-pi)','x(0)=0.5','Dx(0)=1');
fprintf('a) dsolve:')
pretty(x)

%part b
fprintf('b) laplace and inverse laplace:')

syms x(t) t s X
F= diff(x(t),t,2)+2*diff(x(t),t)+26*x(t)==10*cos(t)*heaviside(t-pi);
L = laplace(F, t, s);
lt =  subs(L, laplace(x, t, s), X);
lt = subs(lt, x(0), 0.5);
lt = subs(lt, subs(diff(x(t), t), t, 0), 1);
q = solve(lt,X);
%q = laplace(F,s);
pretty(q)

i = ilaplace(q, s, t);
pretty(i)

%partc
fprintf('c) plot:')

y(t)= dsolve('D2x+2*Dx+26*x-10*cos(t)*heaviside(t-pi)','x(0)=0.5','Dx(0)=1');
y(t)=simplify(y);
s = -5:0.05:10;
sp = y(s);
figure
plot(s, sp, 0, 0.5, 'x')
grid("on")
title('dsolve at od')
xlabel('t')
ylabel('x(t)')

figure
sa = [-5, 10];
fplot(i,sa)
title('inverse laplace of od')
xlabel('t')
ylabel('x(t)')


