clear all
clc
%fprintf("<strong> a)</strong>")
a = [.5, .9, .95, .99, 1];
len = length(a);
n = 500;
xt = zeros(len,n);
for j = 1:len
    xt(j, 1) = randn(1);
    for i = 2:n
        q = (1-(a(j))^2)^(1/2);
        xt(j,i)= a(j)*xt(j,i-1)+q*randn(1);
    end
end


figure
s=1:1:n;
for j = 1:len
    subplot(len,1,j)
    plot(s,xt(j,:))
    t = 'aplha = ' + string(a(j));
    title(t)
end


fprintf("<strong> c)</strong>")
for i = 1:len
    fprintf('\n')
    fprintf('-----------------------------------------------------------------------')
    fprintf('\n')
    fprintf("alpha calculation theoretically:"+string(a(i)))
    practical= ar(xt(i,2:end),1)
    fprintf('\n')
    fprintf("alpha calculations practically:"+string(-practical.A(2)))
    exp= (1 - (-practical.A(2))^2)^(1/2);
    fprintf('\n')
    fprintf("Experimental values:"+string(exp))
end
